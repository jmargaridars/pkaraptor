protdash

protdash is a lightweight Python toolkit for the analysis of protonation states and local environment features of protein residues.


Installation

1. Clone the repository

git clone https://github.com/(placeholder)/protdash.git
cd protdash


2. Create and activate a Python environment (recommended)

Using conda:

conda create -n protdash python=3.10
conda activate protdash

Or using venv:

python -m venv protdash-env
source protdash-env/bin/activate


3. Install dependencies and the package

From the repository root (where pyproject.toml is located):

pip install -e .

After installation, the following commands should be available:

protdash
protdash-dashboard



Cite Us

If you use this toolkit in published work, please cite:

[Add reference here]